/*
	USE WITH SAMPLE WORLD IN boss_chamber.zip
*/

var Sound = Java.type("org.bukkit.Sound");
var EntityType = Java.type("org.bukkit.entity.EntityType");

var bossArea = Area.convert({ 
				"x" : -1, 
				"y" : 56, 
				"z" : 113, 
				"width" : 1,
				"height" : 3,
				"depth" : 8
			});

var warningArea = Area.convert({
				"x" : -3,
				"y" : 62,
				"z" : 99,
				"width" : 6,
				"height" : 4,
				"depth" : 6
			});

$.registerArea(bossArea);
$.registerArea(warningArea);

bossArea.on("area.enter", function (event) {
	$.block("NETHER_BRICK");
	$.selectAbsolute("-1 - 0 ; 56 - 59 ; 110").fill();
	event.player.playSound(event.player.getLocation(), Sound.PISTON_EXTEND, 1, 1);
	$.spawnEntity(0, 56, 120, EntityType.SNOWMAN);
});

warningArea.on("area.enter", function (event) {
	event.player.sendMessage("Turn around. NOW.");
	event.player.sendMessage("You don't want to see what lies ahead.");
});